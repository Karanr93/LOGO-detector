#import sys
#sys.path.append(r'D:/venv/Lib/site-packages')

import os
import cv2
import ast
import pandas as pd
import base64
import numpy as np
from PIL import Image
from .LP_detect import detect

def bounding_box(img, dh, dw, x, y, w, h,src):	
	l = int((x - w / 2) * dw)
	r = int((x + w / 2) * dw)
	t = int((y - h / 2) * dh)
	b = int((y + h / 2) * dh)

	if l < 0:
		l = 0
	if r > dw - 1:
		r = dw - 1
	if t < 0:
		t = 0
	if b > dh - 1:
		b = dh - 1
		
	cv2.rectangle(img, (l, t), (r, b), (0, 255, 0), 2)
	im = Image.open(src)
	crop = im.crop((l, t, r, b))
	
	font = cv2.FONT_HERSHEY_SIMPLEX
	return crop, img, [l, t, r, b]

def predict(imagepath):
	img_orig = cv2.imread(r'C:\Users\karan.singh.GISBIZDEV.001\Desktop/logo-detector/Allianz-LOGO/' + imagepath)
	flname = str(imagepath).split('/')[2]
	src = r'C:\Users\karan.singh.GISBIZDEV.001\Desktop\logo-detector\Allianz-LOGO/' + imagepath
	wgts = r'C:\Users\karan.singh.GISBIZDEV.001\Desktop\logo-detector\Allianz-LOGO\weights/best.pt'
	detect(src, wgts)
	try:
		op = r"C:\Users\karan.singh.GISBIZDEV.001\Desktop\logo-detector\Allianz-LOGO\runs\detect"
		os.chdir(op)
		all_subdirs = [d for d in os.listdir(op) if os.path.isdir(os.path.join(op,d))]

		print(all_subdirs)

		latest_subdir = max(all_subdirs, key=os.path.getmtime)
		print(latest_subdir)
		extn = flname.split('.')[-1]
		label_file = flname.rstrip(extn) + 'txt'
		label_file = os.path.join(op,latest_subdir,'labels',label_file)
		detectimg = os.path.join(op,latest_subdir,flname)
		dimg = cv2.imread(detectimg)
		cv2.imwrite(r'C:\Users\karan.singh.GISBIZDEV.001\Desktop\logo-detector\Allianz-LOGO\media\Output/'+ flname , dimg)
		detectimg = 'media\Output/'+ flname
		# os.chdir(os.getcwd() + '\\' + latest_subdir + "\\" + "labels")
		if all_subdirs == []:
			df = pd.DataFrame(data = None, index = None, columns = ['label', 'x', 'y','w', 'h', 'conf'])
		else:
			df = pd.read_csv(label_file, header = None, names = ['label', 'x', 'y','w', 'h', 'conf'], sep = ' ', index_col = None)

		df.loc[df['label'] == 0, 'label'] = 'Allianz-LOGO'

		os.chdir(r"C:\Users\karan.singh.GISBIZDEV.001\Desktop\logo-detector\Allianz-LOGO")

		##bounding box function
		

		img_orig.shape

		##bounding box function
		


		dh, dw, _ = img_orig.shape
		coord_list = []
		crop_lst = []
		for i, row  in df.iterrows():
			#print(row['x'])
			x = row['x']
			y = row['y']
			w = row['w']
			h = row['h']
			label = row['label']
			conf = round(row['conf'], 2)
			crop, img_orig, boxB = bounding_box(img_orig, dh, dw, x, y, w, h,src)
			coord_list.append([boxB, label, conf])
			crop_lst.append([crop, label])
			font = cv2.FONT_HERSHEY_SIMPLEX
			text = label + '(' + str(conf) + ')'


			if crop_lst[i][1] == 'Allianz-LOGO':
				logopath = 'media\LOGO/' +str(flname) + '_logo.png'
				sign = Image.fromarray(np.asarray(crop_lst[i][0])).save(r'C:\Users\karan.singh.GISBIZDEV.001\Desktop\logo-detector\Allianz-LOGO/'+logopath)
	except Exception as e:
		print(e)
		logopath=''
		os.chdir(r"C:\Users\karan.singh.GISBIZDEV.001\Desktop\logo-detector\Allianz-LOGO")
	return detectimg,logopath

