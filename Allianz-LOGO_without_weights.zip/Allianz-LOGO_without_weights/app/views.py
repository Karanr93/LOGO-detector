from django.shortcuts import render
from .models import MultipleImage
from app.models import MultipleImage
from app.forms import ImageForm

from django.core.files.storage import FileSystemStorage
from django.core.paginator import Paginator

import base64

from concurrent.futures import ThreadPoolExecutor
from .LP_Masking import predict
# Create your views here.

def upload(request):
    mylst = []
    if request.method == "POST":
        form = ImageForm(request.POST, request.FILES)

        fs = FileSystemStorage()
        myfile = request.FILES.getlist('images')
        print(myfile[:5])
        print('Total images -------> ' + str(len(myfile)))
        for cnt, f in enumerate(myfile):
            print('Image No --------------> ' + str(cnt))
            filename = fs.save(f.name, f)
            uploaded_file_url = fs.url(filename)
            op,logopath = predict(uploaded_file_url)
            if op != None:
                lst = [uploaded_file_url, op, logopath]

                mylst.append(lst)

            else:

                continue
        return render(request, 'index-1.html', {'form' : form, 'img_obj': mylst})
    else:
        form = ImageForm()
        return render(request, 'index-1.html', {'form' : form})


# def main():
#     executor = ThreadPoolExecutor(max_workers=1)
#     task1 = executor.submit(upload(request))
#     # task2 = executor.submit(page_two)
#     # task3 = executor.submit(page_three)


#     executor.shutdown()

# main()